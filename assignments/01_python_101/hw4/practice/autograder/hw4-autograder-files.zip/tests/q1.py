OK_FORMAT = True

test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> import hashlib\n'
                                               '>>> \n'
                                               '>>> def hash_input(input) -> str:\n'
                                               "...     input_bytes = str(input).encode('utf-8')\n"
                                               '...     hash_object = hashlib.sha256(input_bytes)\n'
                                               '...     hash_hex = hash_object.hexdigest()\n'
                                               '...     return hash_hex\n'
                                               '>>> \n'
                                               ">>> assert hash_input(results) == 'beace9b59e8c628c9b18da14cd03eec5a534086934693695d91f1502998f9e64'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
