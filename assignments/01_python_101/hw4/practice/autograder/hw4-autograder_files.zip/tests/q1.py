OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> assert results == [2, 4, 6, 8, 10]\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
